import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This is a superclass that represents all the attack animations of the pokemon in AttackAnimations
 * 
 * @author (Daniel) 
 * @version (1.0)
 */
public class Attack extends Actor
{
    /**
     * Act - do whatever the Attack wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    GreenfootImage image;
    public void act()
    {
        // Add your action code here.
    }
}
